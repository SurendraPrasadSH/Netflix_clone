# Netflix Clone — Frontend

React + Vite + Tailwind CSS frontend served by Nginx inside Docker.

## Quick Start

```bash
cp frontend/.env.example frontend/.env
docker-compose up --build
```

Frontend → http://localhost:8080 | Backend → http://localhost:3000

## Local Dev (no Docker)

```bash
cd frontend
npm install
npm run dev   # http://localhost:5173
```

## Plug-in Checklist
- [ ] src/api/apiClient.js — verify /signup, /login, /logout, /me match your routes
- [ ] src/api/apiClient.js — update moviesApi.getAll() response shape
- [ ] src/pages/HomePage.jsx → categorize() — adjust type field values
- [ ] src/api/apiClient.js → recommendationsApi.get() — switch GET/POST for ML
- [ ] frontend/nginx.conf — update proxy_pass if backend uses a path prefix
- [ ] docker-compose.yml — add Supabase env vars to backend service only
